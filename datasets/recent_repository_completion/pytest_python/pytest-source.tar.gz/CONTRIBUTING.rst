============================
Contributing
============================

Contributions are highly welcomed and appreciated.  Every little bit of help counts,
so do not hesitate!


.. _submitfeedback:

Feature requests and feedback
-----------------------------

Do you like pytest?  Share some love on social media or in your blog posts!

We'd also like to hear about your propositions and suggestions.  Feel free to
`submit them as issues <https://github.com/pytest-dev/pytest/issues>`_ and:

* Explain in detail how they should work.
* Keep the scope as narrow as possible.  This will make it easier to implement.


.. _reportbugs:

Report bugs
-----------

Report bugs for pytest in the `issue tracker <https://github.com/pytest-dev/pytest/issues>`_.

If you are reporting a bug, please include:

* Your operating system name and version.
* Any details about your local setup that might be helpful in troubleshooting,
  specifically the Python interpreter version, installed libraries, and pytest
  version.
* Detailed steps to reproduce the bug.

If you can write a demonstration test that currently fails but should pass
(xfail), that is a very useful commit to make as well, even if you cannot
fix the bug itself.


.. _fixbugs:

Fix bugs
--------

Look through the `GitHub issues for bugs <https://github.com/pytest-dev/pytest/labels/type:%20bug>`_.
See also the `"good first issue" issues <https://github.com/pytest-dev/pytest/labels/good%20first%20issue>`_
that are friendly to new contributors.

`Talk to developers <https://docs.pytest.org/en/stable/contact.html>`_ to find out how you can fix specific bugs. To indicate that you are going
to work on a particular issue, add a comment to that effect on the specific issue.

Don't forget to check the issue trackers of your favourite plugins, too!

.. _writeplugins:

Implement features
------------------

Look through the `GitHub issues for enhancements <https://github.com/pytest-dev/pytest/labels/type:%20enhancement>`_.

`Talk to developers <https://docs.pytest.org/en/stable/contact.html>`_ to find out how you can implement specific
features.

Write documentation
-------------------

Pytest could always use more documentation.  What exactly is needed?

* More complementary documentation.  Have you perhaps found something unclear?
* Documentation translations.  We currently have only English.
* Docstrings.  There can never be too many of them.
* Blog posts, articles and such -- they're all very appreciated.

You can also edit documentation files directly in the GitHub web interface,
without using a local copy.  This can be convenient for small fixes.

.. note::
    Build the documentation locally with the following command:

    .. code:: bash

        $ tox -e docs

    The built documentation should be available in ``doc/en/_build/html``,
    where 'en' refers to the documentation language.

Pytest has an API reference which in large part is
`generated automatically <https://www.sphinx-doc.org/en/master/usage/extensions/autodoc.html>`_
from the docstrings of the documented items. Pytest uses the
`Sphinx docstring format <https://sphinx-rtd-tutorial.readthedocs.io/en/latest/docstrings.html>`_.
For example:

.. code-block:: python

    def my_function(arg: ArgType) -> Foo:
        """Do important stuff.

        More detailed info here, in separate paragraphs from the subject line.
        Use proper sentences -- start sentences with capital letters and end
        with periods.

        Can include annotated documentation:

        :param short_arg: An argument which determines stuff.
        :param long_arg:
            A long explanation which spans multiple lines, overflows
            like this.
        :returns: The result.
        :raises ValueError:
            Detailed information when this can happen.

        .. versionadded:: 6.0

        Including types into the annotations above is not necessary when
        type-hinting is being used (as in this example).
        """


.. _submitplugin:

Submitting Plugins to pytest-dev
--------------------------------

Development of the pytest core, support code, and some plugins happens
in repositories living under the ``pytest-dev`` organisations:

- `pytest-dev on GitHub <https://github.com/pytest-dev>`_

All pytest-dev Contributors team members have write access to all contained
repositories.  Pytest core and plugins are generally developed
using `pull requests`_ to respective repositories.

The objectives of the ``pytest-dev`` organisation are:

* Having a central location for popular pytest plugins
* Sharing some of the maintenance responsibility (in case a maintainer no
  longer wishes to maintain a plugin)

You can submit your plugin by posting a new topic in the `pytest-dev GitHub Discussions
<https://github.com/pytest-dev/pytest/discussions>`_ pointing to your existing pytest plugin repository which must have
the following:

- PyPI presence with packaging metadata that contains a ``pytest-``
  prefixed name, version number, authors, short and long description.

- a `tox configuration <https://tox.readthedocs.io/en/latest/config.html#configuration-discovery>`_
  for running tests using `tox <https://tox.readthedocs.io>`_.

- a ``README`` describing how to use the plugin and on which
  platforms it runs.

- a ``LICENSE`` file containing the licensing information, with
  matching info in its packaging metadata.

- an issue tracker for bug reports and enhancement requests.

- a `changelog <https://keepachangelog.com/>`_.

If no contributor strongly objects and two agree, the repository can then be
transferred to the ``pytest-dev`` organisation.

Here's a rundown of how a repository transfer usually proceeds
(using a repository named ``joedoe/pytest-xyz`` as example):

* ``joedoe`` transfers repository ownership to ``pytest-dev`` administrator ``calvin``.
* ``calvin`` creates ``pytest-xyz-admin`` and ``pytest-xyz-developers`` teams, inviting ``joedoe`` to both as **maintainer**.
* ``calvin`` transfers repository to ``pytest-dev`` and configures team access:

  - ``pytest-xyz-admin`` **admin** access;
  - ``pytest-xyz-developers`` **write** access;

The ``pytest-dev/Contributors`` team has write access to all projects, and
every project administrator is in it. We recommend that each plugin has at least three
people who have the right to release to PyPI.

Repository owners can rest assured that no ``pytest-dev`` administrator will ever make
releases of your repository or take ownership in any way, except in rare cases
where someone becomes unresponsive after months of contact attempts.
As stated, the objective is to share maintenance and avoid "plugin-abandon".


.. _ai-contributions:

AI/LLM-Assisted Contributions Policy
-------------------------------------

We welcome contributions from all developers, including those who use AI/LLM tools
as part of their workflow. We genuinely encourage you to reach for these tools when
they help you learn, explore, and produce better work. However, we have requirements
to protect the time and effort of our reviewers:

**We use these tools ourselves.** Several pytest-core maintainers have access to
Anthropic's open-source grant (including Opus on Claude Max). We reach for AI daily
and value it — which is exactly why this policy is about *human effort*, not about the
tools. The bar is the one we hold ourselves to: understand what you ship, and stand
behind it.

**Real effort earns real investment.** If you have genuinely worked on a change — even
a rough or imperfect one — and can talk about it, we are glad to review it, give
feedback, and help you improve it, AI-assisted or not. What we ask for is your
engagement, not perfection. The line is human effort and accountability, never the
tools you used to get there.

**You are responsible for your contribution.** Regardless of how the code was
produced, the person submitting a pull request must understand the changes and be
able to respond to review feedback. If a reviewer asks questions or requests changes,
they expect to interact with someone who can engage substantively, not an automated
loop replaying prompts.

**Purely agentic contributions are not accepted.** Pull requests that are entirely
generated by AI agents, with no meaningful human review, understanding, or oversight,
will be closed. Every contribution must demonstrate that a human has reviewed,
understood, and taken responsibility for the changes. If you submit it, you own it.

**Unattended automation is an attack on the commons.** A contribution that shows
little to no human effort — unattended agent output, bulk-generated changes, PRs the
author cannot explain — is not collaboration. It is a denial-of-service on a volunteer
team: it spends finite review capacity that belongs to people who are genuinely trying
to learn and build. This is bigger than pytest — flooding *any* open-source project
with unattended AI output is hostile to a shared resource all of us depend on.

**We recognize the patterns, and we ban with prejudice.** Having driven these tools
daily, we know the tell-tale signatures of unattended agent output ("clankers"): the
generic commit prose, the confidently-wrong diffs, the inability to answer a simple
"why," the drive-by PR against an issue the author never engaged with. We will be
honest: the last several months of painful, low-quality bot contributions have left us
trigger-happy, and when those patterns show up we no longer spend a review cycle
coaxing a bot — we close and ban with prejudice. If you are a real person who happens
to trip a false positive, just talk to us; a human who understands their change is
always welcome, and we would far rather talk to you than to a script.

**Credit AI tools via attribution.** If AI agents helped produce your code or
commits, consider adding ``Co-authored-by`` trailers to your commit messages to
credit them. This is not required, but helps reviewers set expectations and is
appreciated.


Context
~~~~~~~

With the advent of unsupervised agentic tools like OpenClaw,
there has been a rise in low-quality contributions
where an agent produces a large number of low-quality pull requests.
Oftentimes this can look similar to a human beginner with new access to tools
and trying to learn, but in practice it is usually an unsupervised agentic tool
generating changes without meaningful human review.

When a human contributor is learning, we are glad to invest time to help,
give feedback, and guide them in the right direction. With fully agentic,
unsupervised tools, that same review effort does not support anyone's learning
or growth. Instead, it diverts limited maintainer time away from improving the
project and supporting engaged contributors.

There is also an asymmetry at play: someone is prioritizing what we review
without making an equivalent investment of time or effort.
When a contributor works on an issue themselves, they invest real time, effectively
earning influence over what the project focuses on. Unsupervised agentic contributions
expect to set that priority at near-zero cost to the sender, while shifting the
entire burden onto maintainers.

Fully agentic contributions invert the intended benefit of these tools: rather than
saving time, they create avoidable review and triage work. There is no accountable
human author thoughtfully iterating on feedback, only automated output driven
by prompts.

From our own experience using coding agents, we know they must be carefully prompted,
supervised, and checked by humans. Even modern models can make serious mistakes when
operating at framework or tooling level, and those mistakes can be subtle and
time-consuming to diagnose.

Running such tools unsupervised on open-source projects imposes this cost on
maintainers and other contributors without their consent. Our goal with this policy
is to set clear expectations, protect reviewer time, and ensure that contributions
remain collaborative, respectful, and sustainable.


.. _`pull requests`:
.. _pull-requests:

Preparing Pull Requests
-----------------------

Short version
~~~~~~~~~~~~~

#. Fork the repository.
#. Fetch tags from upstream if necessary (if you cloned only main `git fetch --tags https://github.com/pytest-dev/pytest`).
#. Enable and install `pre-commit <https://pre-commit.com>`_ to ensure style-guides and code checks are followed.
#. Follow `PEP-8 <https://www.python.org/dev/peps/pep-0008/>`_ for naming.
#. Tests are run using ``tox``::

    tox -e linting,py313

   The test environments above are usually enough to cover most cases locally.

#. Write a ``changelog`` entry: ``changelog/2574.bugfix.rst``, use issue id number
   and one of ``feature``, ``improvement``, ``bugfix``, ``doc``, ``deprecation``,
   ``breaking``, ``vendor``, ``packaging``, ``contrib``, or ``misc`` for the issue type.


#. Unless your change is a trivial or a documentation fix (e.g., a typo or reword of a small section) please
   add yourself to the ``AUTHORS`` file, in alphabetical order.


Long version
~~~~~~~~~~~~

What is a "pull request"?  It informs the project's core developers about the
changes you want to review and merge.  Pull requests are stored on
`GitHub servers <https://github.com/pytest-dev/pytest/pulls>`_.
Once you send a pull request, we can discuss its potential modifications and
even add more commits to it later on. There's an excellent tutorial on how Pull
Requests work in the
`GitHub Help Center <https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests>`_.

Here is a simple overview, with pytest-specific bits:

#. Fork the
   `pytest GitHub repository <https://github.com/pytest-dev/pytest>`__.  It's
   fine to use ``pytest`` as your fork repository name because it will live
   under your user.

#. Clone your fork locally using `git <https://git-scm.com/>`_ and create a branch::

    $ git clone git@github.com:YOUR_GITHUB_USERNAME/pytest.git
    $ cd pytest
    $ git fetch --tags https://github.com/pytest-dev/pytest
    # now, create your own branch off "main":

        $ git checkout -b your-bugfix-branch-name main

   Given we have "major.minor.micro" version numbers, bug fixes will usually
   be released in micro releases whereas features will be released in
   minor releases and incompatible changes in major releases.

   You will need the tags to test locally, so be sure you have the tags from the main repository. If you suspect you don't, set the main repository as upstream and fetch the tags::

     $ git remote add upstream https://github.com/pytest-dev/pytest
     $ git fetch upstream --tags

   If you need some help with Git, follow this quick start
   guide: https://git.wiki.kernel.org/index.php/QuickStart

#. Install `pre-commit <https://pre-commit.com>`_ and its hook on the pytest repo::

     $ pip install --user pre-commit
     $ pre-commit install

   Afterwards ``pre-commit`` will run whenever you commit.

   https://pre-commit.com/ is a framework for managing and maintaining multi-language pre-commit hooks
   to ensure code-style and code formatting is consistent.

#. Install tox

   Tox is used to run all the tests and will automatically setup virtualenvs
   to run the tests in.
   (will implicitly use https://virtualenv.pypa.io/en/latest/)::

    $ pip install tox

#. Run all the tests

   You need to have a supported Python version available in your system.  Now
   running tests is as simple as issuing this command::

    $ tox -e linting,py

   This command will run tests via the "tox" tool against your default Python
   version and also perform "lint" coding-style checks.

#. You can now edit your local working copy and run the tests again as necessary. Please follow `PEP-8 <https://www.python.org/dev/peps/pep-0008/>`_ for naming.

   You can pass different options to ``tox``. For example, to run tests on Python 3.13 and pass options to pytest
   (e.g. enter pdb on failure) you can do::

    $ tox -e py313 -- --pdb

   Or to only run tests in a particular test module on Python 3.12::

    $ tox -e py312 -- testing/test_config.py


   When committing, ``pre-commit`` will re-format the files if necessary.

#. If instead of using ``tox`` you prefer to run the tests directly, then we suggest to create a virtual environment and
   install the project together with the ``dev`` :pep:`735` dependency group (requires ``pip`` 25.1+)::

       $ python3 -m venv .venv
       $ source .venv/bin/activate  # Linux
       $ .venv/Scripts/activate.bat  # Windows
       $ pip install -e . --group dev

   Alternatively, with ``uv``::

       $ uv sync --group dev

   Afterwards, you can edit the files and run pytest normally::

       $ pytest testing/test_config.py

#. Create a new changelog entry in ``changelog``. The file should be named ``<issueid>.<type>.rst``,
   where *issueid* is the number of the issue related to the change and *type* is one of
   ``feature``, ``improvement``, ``bugfix``, ``doc``, ``deprecation``, ``breaking``, ``vendor``,
   ``packaging``, ``contrib``, or ``misc``.
   You may skip creating the changelog entry if the change doesn't affect the
   documented behaviour of pytest.

#. Add yourself to ``AUTHORS`` file if not there yet, in alphabetical order.

#. Commit and push once your tests pass and you are happy with your change(s)::

    $ git commit -a -m "<commit message>"
    $ git push -u

#. Finally, submit a pull request through the GitHub website using this data::

    head-fork: YOUR_GITHUB_USERNAME/pytest
    compare: your-branch-name

    base-fork: pytest-dev/pytest
    base: main


Writing Tests
~~~~~~~~~~~~~

Writing tests for plugins or for pytest itself is often done using the `pytester fixture <https://docs.pytest.org/en/stable/reference/reference.html#pytester>`_, as a "black-box" test.

For example, to ensure a simple test passes you can write:

.. code-block:: python

    def test_true_assertion(pytester):
        pytester.makepyfile(
            """
            def test_foo():
                assert True
        """
        )
        result = pytester.runpytest()
        result.assert_outcomes(failed=0, passed=1)


Alternatively, it is possible to make checks based on the actual output of the terminal using
*glob-like* expressions:

.. code-block:: python

    def test_true_assertion(pytester):
        pytester.makepyfile(
            """
            def test_foo():
                assert False
        """
        )
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(["*assert False*", "*1 failed*"])

When choosing a file where to write a new test, take a look at the existing files and see if there's
one file which looks like a good fit. For example, a regression test about a bug in the ``--lf`` option
should go into ``test_cacheprovider.py``, given that this option is implemented in ``cacheprovider.py``.
If in doubt, go ahead and open a PR with your best guess and we can discuss this over the code.

Joining the Development Team
----------------------------

Commit access is an invitation the development team extends once a contributor
has shown a developed sense for the project -- its scope, its conventions, and
what a change costs the people who depend on it.  We look for that across
contributions, reviews and discussions rather than in any single pull request,
so there is nothing to clear on demand; if we haven't reached out yet, that is
not a verdict on your work -- sometimes no-one has thought to offer.

The invitation does not change how you contribute: everyone goes through the
same pull-request-and-review process, and no-one merges their own pull requests
unless already approved.  It does mean you can take a fuller part in the
development process, since you can merge other contributors' pull requests once
you have reviewed them.


Merge/squash guidelines
-----------------------

When a PR is approved and ready to be integrated to the ``main`` branch, one has the option to *merge* the commits unchanged, or *squash* all the commits into a single commit.

Here are some guidelines on how to proceed, based on examples of a single PR commit history:

1. Miscellaneous commits:

   * ``Implement X``
   * ``Fix test_a``
   * ``Add myself to AUTHORS``
   * ``fixup! Fix test_a``
   * ``Update tests/test_integration.py``
   * ``Merge origin/main into PR branch``
   * ``Update tests/test_integration.py``

   In this case, prefer to use the **Squash** merge strategy: the commit history is a bit messy (not in a derogatory way, often one just commits changes because they know the changes will eventually be squashed together), so squashing everything into a single commit is best. You must clean up the commit message, making sure it contains useful details.

2. Separate commits related to the same topic:

   * ``Implement X``
   * ``Add myself to AUTHORS``
   * ``Update CHANGELOG for X``

   In this case, prefer to use the **Squash** merge strategy: while the commit history is not "messy" as in the example above, the individual commits do not bring much value overall, specially when looking at the changes a few months/years down the line.

3. Separate commits, each with their own topic (refactorings, renames, etc), but still have a larger topic/purpose.

   * ``Refactor class X in preparation for feature Y``
   * ``Remove unused method``
   * ``Implement feature Y``

   In this case, prefer to use the **Merge** strategy: each commit is valuable on its own, even if they serve a common topic overall. Looking at the history later, it is useful to have the removal of the unused method separately on its own commit, along with more information (such as how it became unused in the first place).

4. Separate commits, each with their own topic, but without a larger topic/purpose other than improve the code base (using more modern techniques, improve typing, removing clutter, etc).

   * ``Improve internal names in X``
   * ``Add type annotations to Y``
   * ``Remove unnecessary dict access``
   * ``Remove unreachable code due to EOL Python``

   In this case, prefer to use the **Merge** strategy: each commit is valuable on its own, and the information on each is valuable in the long term.


As mentioned, those are overall guidelines, not rules cast in stone. This topic was discussed in `#12633 <https://github.com/pytest-dev/pytest/discussions/12633>`_.


*Backport PRs* (as those created automatically from a ``backport`` label) should always be **squashed**, as they preserve the original PR author.


Backporting bug fixes for the next patch release
------------------------------------------------

Pytest makes a feature release every few weeks or months. In between, patch releases
are made to the previous feature release, containing bug fixes only. The bug fixes
usually fix regressions, but may be any change that should reach users before the
next feature release.

Suppose for example that the latest release was 1.2.3, and you want to include
a bug fix in 1.2.4 (check https://github.com/pytest-dev/pytest/releases for the
actual latest release). The procedure for this is:

#. First, make sure the bug is fixed in the ``main`` branch, with a regular pull
   request, as described above. An exception to this is if the bug fix is not
   applicable to ``main`` anymore.

Automatic method:

Add a ``backport 1.2.x`` label to the PR you want to backport. This will create
a backport PR against the ``1.2.x`` branch.

Manual method:

#. ``git checkout origin/1.2.x -b backport-XXXX`` # use the main PR number here

#. Locate the merge commit on the PR, in the *merged* message, for example:

    nicoddemus merged commit 0f8b462 into pytest-dev:main

#. ``git cherry-pick -x -m1 REVISION`` # use the revision you found above (``0f8b462``).

#. Open a PR targeting ``1.2.x``:

   * Prefix the message with ``[1.2.x]``.
   * Delete the PR body, it usually contains a duplicate commit message.


Who does the backporting
~~~~~~~~~~~~~~~~~~~~~~~~

As mentioned above, bugs should first be fixed on ``main`` (except in rare occasions
that a bug only happens in a previous release). So, who should do the backport procedure described
above?

1. If the bug was fixed by a core developer, it is the main responsibility of that core developer
   to do the backport.
2. However, often the merge is done by another maintainer, in which case it is nice of them to
   do the backport procedure if they have the time.
3. For bugs submitted by non-maintainers, it is expected that a core developer will do
   the backport, normally the one that merged the PR on ``main``.
4. If a non-maintainer notices a bug which is fixed on ``main`` but has not been backported
   (due to maintainers forgetting to apply the *needs backport* or *backport x.x.x* labels, or just plain missing it),
   they are also welcome to open a PR with the backport. The procedure is simple and really
   helps with the maintenance of the project.

All the above are not rules, but merely some guidelines/suggestions on what we should expect
about backports.

Backports should be **squashed** (rather than **merged**), as doing so preserves the original PR author correctly.

Handling stale issues/PRs
-------------------------

Stale issues/PRs are those where pytest contributors have asked for questions/changes
and the authors didn't get around to answer/implement them yet after a somewhat long time, or
the discussion simply died because people seemed to lose interest.

There are many reasons why people don't answer questions or implement requested changes:
they might get busy, lose interest, or just forget about it,
but the fact is that this is very common in open source software.

The pytest team really appreciates every issue and pull request, but being a high-volume project
with many issues and pull requests being submitted daily, we try to reduce the number of stale
issues and PRs by regularly closing them. When an issue/pull request is closed in this manner,
it is by no means a dismissal of the topic being tackled by the issue/pull request, but it
is just a way for us to clear up the queue and make the maintainers' work more manageable. Submitters
can always reopen the issue/pull request in their own time later if it makes sense.

When to close
~~~~~~~~~~~~~

Here are a few general rules the maintainers use to decide when to close issues/PRs because
of lack of inactivity:

* Issues labeled ``question`` or ``needs information``: closed after 14 days inactive.
* Issues labeled ``proposal``: closed after six months inactive.
* Pull requests: after one month, consider pinging the author, update linked issue, or consider closing. For pull requests which are nearly finished, the team should consider finishing it up and merging it.

The above are **not hard rules**, but merely **guidelines**, and can be (and often are!) reviewed on a case-by-case basis.

Closing pull requests
~~~~~~~~~~~~~~~~~~~~~

When closing a Pull Request, we should acknowledge the time, effort, and interest demonstrated by the person who submitted it. As mentioned previously, it is not the intent of the team to dismiss a stalled pull request entirely but to merely to clear up our queue, so a message like the one below is warranted when closing a pull request that went stale:

    Hi <contributor>,

    First of all, we would like to thank you for your time and effort on working on this, the pytest team deeply appreciates it.

    We noticed it has been awhile since you have updated this PR, however. pytest is a high activity project, with many issues/PRs being opened daily, so it is hard for us maintainers to track which PRs are ready for merging, for review, or need more attention.

    So for those reasons, we think it is best to close the PR for now, but with the only intention to clean up our queue, it is by no means a rejection of your changes. We still encourage you to re-open this PR (it is just a click of a button away) when you are ready to get back to it.

    Again we appreciate your time for working on this, and hope you might get back to this at a later time!

    <bye>

Closing issues
--------------

When a pull request is submitted to fix an issue, add text like ``closes #XYZW`` to the PR description and/or commits (where ``XYZW`` is the issue number). See the `GitHub docs <https://help.github.com/en/github/managing-your-work-on-github/linking-a-pull-request-to-an-issue#linking-a-pull-request-to-an-issue-using-a-keyword>`_ for more information.

When an issue is due to user error (e.g. misunderstanding of a functionality), please politely explain to the user why the issue raised is really a non-issue and ask them to close the issue if they have no further questions. If the original requester is unresponsive, the issue will be handled as described in the section `Handling stale issues/PRs`_ above.
